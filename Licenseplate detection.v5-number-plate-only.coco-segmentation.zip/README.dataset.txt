# Licenseplate detection > Number Plate Only
https://universe.roboflow.com/fyp-munle/licenseplate-detection-jwhkm

Provided by a Roboflow user
License: CC BY 4.0

